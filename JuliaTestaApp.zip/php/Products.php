<?php
include ("../shopify/private/consultas.php");
$shopify     = new shopify();
$result      = $shopify->getViewProducts();
?>

